import { useState } from "react";
import axios from "axios";

const AudioUploader = () => {
  const [file, setFile] = useState(null);
  const [transcription, setTranscription] = useState("");
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) {
      alert("Please select an audio file first!");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);
    setLoading(true);

    try {
      const response = await axios.post("http://localhost:8080", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      setTranscription(response.data);
    } catch (error) {
      console.error("Error Transcribing Audio", error);
      setTranscription("An error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ textAlign: "center", padding: "20px", fontFamily: "Arial, sans-serif" }}>
      <h1 style={{ color: "#4a90e2", fontSize: "36px", marginBottom: "10px" }}>EchoScribe</h1>
      <p style={{ fontStyle: "italic", color: "#888", marginBottom: "30px" }}>
        "Turning Sound into Script"
      </p>

      <div style={{ marginBottom: "20px" }}>
        <input
          type="file"
          accept="audio/*"
          onChange={handleFileChange}
          style={{
            padding: "10px",
            border: "2px solid #4a90e2",
            borderRadius: "5px",
            fontSize: "16px",
          }}
        />
      </div>

      <button
        onClick={handleUpload}
        style={{
          backgroundColor: "#4a90e2",
          color: "white",
          padding: "10px 20px",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
          fontSize: "16px",
        }}
      >
        {loading ? "Transcribing..." : "Whisper to Text"}
      </button>

      <div style={{ marginTop: "30px", fontSize: "18px" }}>
        <h2 style={{ color: "#4a90e2" }}>Your Transcription</h2>
        {loading ? (
          <p>Processing your audio...</p>
        ) : (
          <p
            style={{
              whiteSpace: "pre-wrap",
              backgroundColor: "#f9f9f9",
              padding: "20px",
              borderRadius: "10px",
              border: "1px solid #ddd",
              color: transcription ? "black" : "#888", // Set the color to black when transcription exists
            }}
          >
            {transcription || "Your transcribed text will appear here."}
          </p>
        )}
      </div>
    </div>
  );
};

export default AudioUploader;
