package com.audio.Audio_to_text;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AudioToTextApplication {

	public static void main(String[] args) {
		SpringApplication.run(AudioToTextApplication.class, args);
	}

}
