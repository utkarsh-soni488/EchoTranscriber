package com.audio.Audio_to_text;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AudioToTextApplicationTests {

	@Test
	void contextLoads() {
	}

}
